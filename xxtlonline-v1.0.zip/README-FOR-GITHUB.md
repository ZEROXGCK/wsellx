# XXTLONLINE VPN Panel v1.0

**Modern, Production-Ready VPN SSH Panel with Admin Dashboard**

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Status](https://img.shields.io/badge/status-Production%20Ready-brightgreen.svg)
![Ubuntu](https://img.shields.io/badge/Ubuntu-22.04%20%7C%2024.04%20%7C%2026.04-orange.svg)

---

## 🚀 Quick Installation

### One-liner (Easiest)
```bash
curl -Ls https://raw.githubusercontent.com/ZEROXGCK/phttixxtlonlinevip/main/xxtlonline-setup.sh | bash
```

### Or Manual
```bash
git clone https://github.com/ZEROXGCK/phttixxtlonlinevip.git
cd phttixxtlonlinevip
bash xxtlonline-setup.sh
```

---

## ✨ Features

### Infrastructure
- **3x-ui v2.9.4** (Locked) - VLESS/VMess/Trojan proxy panel
- **Dropbear SSH** - Lightweight SSH server (ports 143, 109)
- **Nginx** - SSL reverse proxy & dashboard
- **WS-Stunnel** - HTTP-CONNECT tunnel (port 80)
- **BadVPN UDP** - UDP relay gateway
- **SSH REST API** - Programmatic user management

### Dashboard & UI
- **Modern Design** - Minimal white/pastel theme
- **User Management** - Create/delete/extend SSH users
- **Service Monitor** - Real-time status of all services
- **Connection Tracking** - Active connections & user count
- **Responsive** - Works on mobile & desktop

### Admin Panel (Settings)
- **6 Comprehensive Tabs**
  - Overview - System stats
  - Server - Domain & configuration
  - Security - Passwords, SSL, firewall
  - Network - Tuning & optimization
  - Backup - Create & restore
  - System - Service management & logs

### Tools & Utilities
- **xxtlonline-utils.sh** - Daily operations
- **xxtlonline-patches.sh** - 4 UI themes
- **Management CLI** - Full command-line control

### Optimization
- **BBR Congestion Control** - High throughput
- **FQ Queue Discipline** - Fair queuing
- **TCP Tuning** - Buffer optimization
- **RPS/RFS** - Interrupt routing
- **IRQ Balancing** - CPU optimization

### Security
- **Auto SSL** - Let's Encrypt certificates
- **Firewall** - UFW preconfigured
- **User Expiry** - Automatic account expiration
- **SSH Hardening** - Password auth enabled
- **API Localhost-Only** - No WAN exposure

---

## 📋 Requirements

### Server
- **OS:** Ubuntu 22.04, 24.04, or 26.04 LTS
- **RAM:** 1GB minimum (2GB+ recommended)
- **Disk:** 5GB minimum
- **Network:** Public IPv4, port 443 outbound
- **Domain:** A record pointing to server IP

### Supported Providers
- ✅ DigitalOcean, Linode, AWS, Azure
- ✅ Vultr, Hetzner, OVH
- ✅ Alibaba Cloud, Tencent Cloud
- ✅ Most standard VPS providers

---

## 📚 Documentation

| File | Purpose |
|------|---------|
| **START_HERE.txt** | Quick navigation guide |
| **QUICKSTART.md** | 5-minute setup walkthrough |
| **README.md** | Complete feature reference |
| **INSTALL_GUIDE.md** | Detailed installation guide |
| **SETTINGS-INTEGRATION.md** | How to add admin settings |
| **API.md** | REST API documentation |

---

## 🎯 Installation Steps

### 1. Prepare Domain
```bash
# Add DNS A record
# panel.example.com → YOUR_SERVER_IP
# Wait 5-10 minutes for propagation
nslookup panel.example.com  # Should show your IP
```

### 2. SSH Into Server
```bash
ssh root@YOUR_SERVER_IP
# or
ssh root@panel.example.com
```

### 3. Run Installer
```bash
curl -Ls https://raw.githubusercontent.com/ZEROXGCK/phttixxtlonlinevip/main/xxtlonline-setup.sh | bash
```

### 4. Answer Prompts
- Domain: `panel.example.com`
- Admin Username: `admin` (or your choice)
- Admin Password: (strong password)
- IPv4/IPv6: Choose preference

### 5. Wait 5-10 Minutes
Installation is automatic. Grab coffee! ☕

### 6. Access Dashboard
```
https://panel.example.com
Username: admin
Password: (your password)
```

---

## 🔧 Common Commands

### Check Status
```bash
sudo xxtlonline-utils.sh status
```

### Create SSH User
```bash
sudo xxtlonline-utils.sh user-create
# Follow prompts for username, password, days valid
```

### List Users
```bash
sudo xxtlonline-utils.sh user-list
```

### Create Backup
```bash
sudo xxtlonline-utils.sh backup
```

### View Logs
```bash
sudo xxtlonline-utils.sh logs xui
sudo xxtlonline-utils.sh logs dropbear
```

### Change UI Theme
```bash
sudo bash xxtlonline-patches.sh color-neon-pink
# Options: dark-purple, neon-pink, forest, ocean
```

### Full Help
```bash
sudo xxtlonline-utils.sh --help
sudo bash xxtlonline-patches.sh --help
```

---

## 🔗 Port Map

| Port | Service | Purpose |
|------|---------|---------|
| 22 | OpenSSH | Standard SSH |
| 80 | WS-Stunnel | HTTP-CONNECT tunnel → Dropbear |
| 109 | Dropbear | Alternate SSH |
| 143 | Dropbear | Primary SSH |
| 443 | Nginx | HTTPS dashboard |
| 2503 | Nginx | 3x-ui reverse proxy |
| 6789 | SSH API | REST API (localhost) |
| 7300 | BadVPN | UDP gateway (localhost) |
| 8080, 8880 | 3x-ui | VLESS inbounds |
| 54321 | 3x-ui | Internal panel |

---

## 🔐 Security Features

### Enabled by Default
✅ SSL/TLS via Let's Encrypt  
✅ Firewall (UFW) preconfigured  
✅ SSH hardening  
✅ 1M+ file descriptors  
✅ Network tuning (BBR, FQ)  
✅ User expiry tracking  
✅ API localhost-only  

### Recommended
🔒 Change admin password quarterly  
🔒 Monitor logs weekly  
🔒 Create backups regularly  
🔒 Keep SSH credentials secure  

---

## 🆘 Troubleshooting

### Can't reach dashboard
```bash
# Check SSL certificate
sudo certbot certificates

# Check Nginx status
sudo systemctl status nginx

# Test connection
curl -I https://panel.example.com
```

### SSH won't connect
```bash
# Check Dropbear
sudo systemctl status dropbear

# Test port
ssh -vvv -p 143 user@panel.example.com
```

### Services failing
```bash
# View diagnostics
sudo xxtlonline-utils.sh diagnostics

# Check logs
sudo journalctl -u xxtlonline-ssh-api -n 50
```

### More help
See **README.md** → Troubleshooting section

---

## 📊 What's Installed

### Services
- OpenSSH (port 22)
- Dropbear (port 143, 109)
- Nginx (port 80, 443)
- 3x-ui (port 54321)
- WS-Stunnel (port 80)
- BadVPN (port 7300, UDP)
- SSH API (port 6789)

### Tools
- Certbot (SSL renewal)
- Python 3 (API runtime)
- UFW (Firewall)
- ethtool (Network tuning)

### Disk Usage
~2-3 GB after installation

---

## 🎨 Customization

### Change Theme
```bash
sudo bash xxtlonline-patches.sh color-neon-pink
# Options: dark-purple, neon-pink, forest, ocean
```

### Change Branding
```bash
sudo bash xxtlonline-patches.sh logo-change "MY VPN PANEL"
```

### Apply Custom CSS
```bash
sudo bash xxtlonline-patches.sh custom-css ./my-theme.css
```

---

## 📞 Support

### Getting Help
1. Read **QUICKSTART.md** (5-minute guide)
2. Check **README.md** → Troubleshooting
3. Review **INSTALL_GUIDE.md** (detailed)
4. Run diagnostics: `sudo xxtlonline-utils.sh diagnostics`

### Logs
```bash
# View service logs
sudo journalctl -u xxtlonline-ssh-api -n 50
sudo journalctl -u x-ui -n 50
sudo journalctl -u dropbear -n 50

# Follow logs in real-time
sudo journalctl -u xxtlonline-ssh-api -f
```

---

## 📈 Performance

### Throughput
- BBR + FQ: 400+ Mbps potential
- Typical VPS: 50-200 Mbps (provider dependent)

### Latency
- Optimized for low jitter
- TCP window scaling enabled
- FQ reduces buffer bloat

### Connections
- 1GB VPS: 50-100 users
- 2GB VPS: 150-200 users
- 4GB VPS: 300-500 users

---

## 🔄 Updates & Maintenance

### Weekly
```bash
sudo xxtlonline-utils.sh status  # Check health
```

### Monthly
```bash
sudo apt update && sudo apt upgrade -y  # System updates
sudo xxtlonline-utils.sh backup         # Create backup
```

### Quarterly
```bash
# Change admin password
# (Via dashboard → Settings → Security)

# Review firewall rules
sudo ufw status
```

### Backup & Restore
```bash
# Create backup
sudo xxtlonline-utils.sh backup

# Restore
sudo xxtlonline-utils.sh restore /root/xxtlonline-backup-*.tar.gz
```

---

## 📄 File Manifest

```
xxtlonline-setup.sh          Main installer
xxtlonline-utils.sh          Daily management
xxtlonline-patches.sh        UI customization
settings.html                Admin panel
SETTINGS-API.py              Settings API
START_HERE.txt               Navigation
QUICKSTART.md                Quick setup
README.md                    Full reference
INSTALL_GUIDE.md             Detailed guide
SETTINGS-INTEGRATION.md      Admin setup
UPDATE-DASHBOARD.txt         Dashboard update
API.md                       API docs
SUMMARY.txt                  Project summary
```

---

## 🎯 Quick Start (TL;DR)

```bash
# 1. Prepare domain (add DNS A record)

# 2. SSH into server
ssh root@YOUR_IP

# 3. Run installer
curl -Ls https://raw.githubusercontent.com/ZEROXGCK/phttixxtlonlinevip/main/xxtlonline-setup.sh | bash

# 4. Answer 4 prompts (domain, username, password, IPv4/6)

# 5. Wait 5-10 minutes

# 6. Access dashboard
# https://panel.example.com

# 7. Create users
# Dashboard → Create SSH Account

# 8. Connect
# ssh -p 143 username@panel.example.com
```

---

## 📝 Changelog

### v1.0 (2026-07-21) - Initial Release
- ✅ Merged 3 installation scripts into unified installer
- ✅ Rebranded from Chaiya VPN to XXTLONLINE
- ✅ Modern minimal dashboard UI (white/pastel)
- ✅ Comprehensive admin settings panel
- ✅ 15+ API endpoints
- ✅ Complete documentation (6 guides)
- ✅ Management utilities
- ✅ Network optimization
- ✅ Production ready

---

## 📜 License

This project is provided as-is. See individual components for their respective licenses.

---

## 🙏 Acknowledgments

- **3x-ui**: [MHSanaei/3x-ui](https://github.com/MHSanaei/3x-ui)
- **Dropbear**: [Matt Johnston](https://matt.ucc.asn.au/dropbear/)
- **BadVPN**: [ambrop72/badvpn](https://github.com/ambrop72/badvpn)

---

## 🚀 Ready to Deploy?

```bash
curl -Ls https://raw.githubusercontent.com/ZEROXGCK/phttixxtlonlinevip/main/xxtlonline-setup.sh | bash
```

**Status:** ✅ Production Ready  
**Version:** 1.0  
**Last Updated:** 2026-07-21

---

**Happy tunneling! 🎉**
