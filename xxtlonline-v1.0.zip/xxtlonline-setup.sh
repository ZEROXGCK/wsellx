#!/bin/bash
# ============================================================
#   XXTLONLINE VPN PANEL — ALL-IN-ONE INSTALLER
#   (3x-ui + Dropbear SSH + BadVPN + Nginx + WS-Stunnel + Network Tuning)
#   Ubuntu 22.04 / 24.04 / 26.04
#   Usage: bash xxtlonline-setup.sh
# ============================================================

# ── SELF-SAVE GUARD ──────────────────────────────────────────
if [[ "$0" == /dev/fd/* ]] || [[ "$0" == /proc/self/fd/* ]] || [[ "$0" == "bash" ]] || [[ "$0" == "-bash" ]] || [[ ! -f "$0" ]]; then
  _SELF=$(mktemp /tmp/xxtlonline-setup-XXXXX.sh)
  echo "[INFO] บันทึก script ลงไฟล์: $_SELF"
  if [[ -r "$0" ]] && cat "$0" > "$_SELF" 2>/dev/null && [[ $(wc -c < "$_SELF") -gt 10000 ]]; then
    chmod +x "$_SELF"; exec bash "$_SELF" "$@"
  fi
  if [[ ! -t 0 ]] && cat > "$_SELF" 2>/dev/null && [[ $(wc -c < "$_SELF") -gt 10000 ]]; then
    chmod +x "$_SELF"; exec bash "$_SELF" "$@"
  fi
  echo "[ERR] ไม่สามารถบันทึก script ลงไฟล์ได้"
  rm -f "$_SELF"; exit 1
fi

set -o pipefail
stty cols 200 2>/dev/null || true
export COLUMNS=200
export DEBIAN_FRONTEND=noninteractive

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
info() { echo -e "${CYAN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERR]${NC} $1"; exit 1; }

cat << 'BANNER'
 __   ___  _____ _     ___  _   _ _     ___ _   _ _____
 \ \ / / |/ /_  _| |   / _ \| \ | | |   |_ _| \ | | ____|
  \ V /| ' /  | | | |  | | | |  \| | |    | ||  \| |  _|
   | | | . \  | | | |__| |_| | |\  | |___ | || |\  | |___
   |_| |_|\_\ |_| |_____\___/|_| \_|_____|___|_| \_|_____|
        VPN PANEL — ALL-IN-ONE INSTALLER
BANNER

[[ $EUID -ne 0 ]] && err "รันด้วย root หรือ sudo เท่านั้น"

BRAND="XXTLONLINE"
BRAND_DIR="xxtlonline"

# ── PORT MAP ────────────────────────────────────────────────
# 80    ws-stunnel HTTP-CONNECT -> Dropbear:143
# 109   Dropbear SSH port 2
# 143   Dropbear SSH port 1
# 443   nginx HTTPS panel
# 2503  nginx SSL proxy -> 3x-ui panel
# 54321 3x-ui internal
# 7300  badvpn-udpgw (127.0.0.1 only)
# 8080  xui VMess/VLESS-WS inbound
# 8880  xui VLESS-WS inbound
# 6789  xxtlonline-ssh-api (127.0.0.1 only)

UBUNTU_VER=$(lsb_release -rs 2>/dev/null || grep VERSION_ID /etc/os-release | cut -d'"' -f2)
info "Ubuntu version: ${CYAN}${UBUNTU_VER}${NC}"
case "$UBUNTU_VER" in
  22.04|24.04|26.04) ok "Ubuntu ${UBUNTU_VER} รองรับแล้ว" ;;
  *) warn "Ubuntu ${UBUNTU_VER} ยังไม่ได้ทดสอบ" ;;
esac

SSH_API_PORT=6789
XUI_PORT=54321
XUI_NGINX_PORT=2503
DROPBEAR_PORT1=143
DROPBEAR_PORT2=109
BADVPN_PORT=7300
WS_TUNNEL_PORT=80

# ── INSTALL DEPS ─────────────────────────────────────────────
info "อัปเดต packages..."
timeout 120 apt-get update -qq -o Acquire::ForceIPv4=true -o Acquire::http::Timeout=30 -o Acquire::https::Timeout=30 2>/dev/null || \
timeout 60 apt-get update -qq -o Acquire::http::Timeout=30 -o Acquire::https::Timeout=30 2>/dev/null || true
ok "apt update เสร็จ"

info "ติดตั้ง packages หลัก..."
DEBIAN_FRONTEND=noninteractive timeout 180 apt-get install -y -qq --no-install-recommends \
  -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" \
  curl wget python3 python3-pip dropbear openssh-server ufw \
  net-tools jq bc cron unzip sqlite3 ethtool irqbalance 2>/dev/null || true
ok "packages หลักเสร็จ"

info "ติดตั้ง certbot..."
if ! command -v certbot &>/dev/null; then
  DEBIAN_FRONTEND=noninteractive timeout 120 apt-get install -y -qq certbot python3-certbot-nginx 2>/dev/null || \
  DEBIAN_FRONTEND=noninteractive timeout 120 apt-get install -y -qq certbot 2>/dev/null || true
fi
if ! command -v certbot &>/dev/null && command -v snap &>/dev/null; then
  timeout 60 snap install --classic certbot 2>/dev/null && ln -sf /snap/bin/certbot /usr/bin/certbot 2>/dev/null || true
fi
command -v certbot &>/dev/null && ok "certbot พร้อม" || warn "certbot ไม่พบ (ติดตั้งทีหลังได้)"

info "ติดตั้ง bcrypt / speedtest-cli..."
pip3 install bcrypt --break-system-packages -q --timeout=30 2>/dev/null || pip3 install bcrypt -q --timeout=30 2>/dev/null || true
pip3 install speedtest-cli --break-system-packages -q --timeout=30 2>/dev/null || pip3 install speedtest-cli -q --timeout=30 2>/dev/null || true
if ! command -v speedtest-cli &>/dev/null && ! python3 -c "import speedtest" 2>/dev/null; then
  _arch=$(uname -m)
  case "$_arch" in x86_64) _sf="x86_64";; aarch64) _sf="aarch64";; armv7l) _sf="armhf";; *) _sf="";; esac
  if [[ -n "$_sf" ]]; then
    wget -q --timeout=30 -O /tmp/speedtest.tgz "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-${_sf}.tgz" 2>/dev/null && \
      tar -xzf /tmp/speedtest.tgz -C /usr/local/bin speedtest 2>/dev/null && chmod +x /usr/local/bin/speedtest && rm -f /tmp/speedtest.tgz
  fi
fi
ok "ติดตั้ง packages สำเร็จ"

# ── GET SERVER IP ────────────────────────────────────────────
SERVER_IP=$(curl -s4 --max-time 5 https://api.ipify.org 2>/dev/null || curl -s4 --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
[[ -z "$SERVER_IP" ]] && err "ไม่สามารถดึง IP ได้"
ok "IPv4: ${CYAN}$SERVER_IP${NC}"

USE_IPV6=0
SERVER_IPV6=""
_ipv6_check=$(ip -6 addr show scope global 2>/dev/null | grep -oP '(?<=inet6 )[0-9a-f:]+' | grep -v '^::1' | head -1)
if [[ -n "$_ipv6_check" ]] && ping6 -c 1 -W 3 google.com &>/dev/null 2>&1; then
  SERVER_IPV6=$(curl -s6 --max-time 5 https://api6.ipify.org 2>/dev/null || echo "$_ipv6_check")
  echo ""
  echo -e "${YELLOW}เซิร์ฟเวอร์นี้มี IPv6: ${CYAN}$SERVER_IPV6${NC}"
  read -rp "  ใช้ IPv6 แทน IPv4 หรือไม่? [y/N]: " _ip_choice
  [[ "$_ip_choice" == "y" || "$_ip_choice" == "Y" ]] && USE_IPV6=1
fi

# ── DOMAIN / CREDENTIALS ──────────────────────────────────────
echo ""
echo -e "${YELLOW}════════════════════════════════════════${NC}"
echo -e "${YELLOW}  ตั้งค่าโดเมน ${BRAND}${NC}"
echo -e "${YELLOW}════════════════════════════════════════${NC}"
echo -e "  DNS ต้องชี้ A record มาที่ IP: ${CYAN}$SERVER_IP${NC} ก่อน"
read -rp "  โดเมน (เช่น panel.example.com): " DOMAIN
[[ -z "$DOMAIN" ]] && err "กรุณาใส่โดเมน"
DOMAIN=$(echo "$DOMAIN" | tr '[:upper:]' '[:lower:]' | sed 's|https\?://||' | sed 's|/.*||')
ok "โดเมน: ${CYAN}$DOMAIN${NC}"

read -rp "  3x-ui Username [admin]: " XUI_USER
[[ -z "$XUI_USER" ]] && XUI_USER="admin"
while true; do
  read -rsp "  3x-ui Password: " XUI_PASS; echo
  [[ -z "$XUI_PASS" ]] && { warn "Password ห้ามว่าง"; continue; }
  read -rsp "  Confirm Password: " XUI_PASS2; echo
  [[ "$XUI_PASS" == "$XUI_PASS2" ]] && break
  warn "Password ไม่ตรงกัน"
done
ok "3x-ui credentials ตั้งค่าแล้ว"

echo ""
read -rp "เริ่มติดตั้ง ${BRAND}? [y/N]: " CONFIRM
[[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]] && exit 0

# ── CLEANUP ────────────────────────────────────────────────
info "ล้างข้อมูลเก่า..."
for _svc in ${BRAND_DIR}-sshws ${BRAND_DIR}-ssh-api ${BRAND_DIR}-badvpn nginx x-ui dropbear chaiya-sshws chaiya-ssh-api chaiya-badvpn; do
  systemctl stop "$_svc" 2>/dev/null || true
  systemctl disable "$_svc" 2>/dev/null || true
done
pkill -f ws-stunnel 2>/dev/null || true
pkill -f badvpn-udpgw 2>/dev/null || true
pkill -f "${BRAND_DIR}-ssh-api" 2>/dev/null || true
pkill -9 -x nginx 2>/dev/null || true
sleep 2

rm -f /etc/nginx/sites-enabled/*
rm -f /etc/nginx/sites-available/${BRAND_DIR}
rm -f /etc/nginx/conf.d/${BRAND_DIR}.conf
rm -f /etc/nginx/conf.d/default.conf
rm -f /etc/nginx/conf.d/chaiya.conf
rm -f /etc/systemd/system/${BRAND_DIR}-sshws.service
rm -f /etc/systemd/system/${BRAND_DIR}-ssh-api.service
rm -f /etc/systemd/system/${BRAND_DIR}-badvpn.service
systemctl daemon-reload

rm -rf /etc/${BRAND_DIR}
rm -rf /opt/${BRAND_DIR}-panel
rm -rf /opt/${BRAND_DIR}-ssh-api
rm -f  /usr/local/bin/ws-stunnel

if [[ -f /etc/x-ui/x-ui.db ]]; then
  sqlite3 /etc/x-ui/x-ui.db "DELETE FROM inbounds;" 2>/dev/null || true
  sqlite3 /etc/x-ui/x-ui.db "DELETE FROM settings;" 2>/dev/null || true
fi

_REQUIRED_PORTS=(80 109 143 443 2503 7300 8080 8880 54321 6789)
for _port in "${_REQUIRED_PORTS[@]}"; do
  _pids=$(lsof -ti tcp:$_port 2>/dev/null); [[ -z "$_pids" ]] && _pids=$(fuser $_port/tcp 2>/dev/null)
  for _pid in $_pids; do kill -9 "$_pid" 2>/dev/null || true; done
done
sleep 1
ok "ล้างข้อมูลเก่าเสร็จแล้ว"

mkdir -p /etc/${BRAND_DIR} /etc/${BRAND_DIR}/exp /opt/${BRAND_DIR}-panel
echo "$XUI_USER"  > /etc/${BRAND_DIR}/xui-user.conf
echo "$XUI_PASS"  > /etc/${BRAND_DIR}/xui-pass.conf
echo "$SERVER_IP" > /etc/${BRAND_DIR}/my_ip.conf
echo "$DOMAIN"    > /etc/${BRAND_DIR}/domain.conf
chmod 600 /etc/${BRAND_DIR}/xui-user.conf /etc/${BRAND_DIR}/xui-pass.conf

# ── OPENSSH ──────────────────────────────────────────────────
info "ตั้งค่า OpenSSH..."
sed -i 's/#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
ok "OpenSSH พร้อม"

# ── DROPBEAR ─────────────────────────────────────────────────
info "ตั้งค่า Dropbear..."
apt-get install -y dropbear 2>/dev/null || timeout 60 apt-get install -y dropbear-bin 2>/dev/null || true
_DB_BIN=""
for _p in /usr/sbin/dropbear /usr/bin/dropbear; do [[ -x "$_p" ]] && _DB_BIN="$_p" && break; done
if [[ -z "$_DB_BIN" ]]; then
  warn "ไม่พบ dropbear binary — ข้ามขั้นตอนนี้"
else
  systemctl stop dropbear 2>/dev/null || true
  mkdir -p /etc/dropbear
  [[ ! -f /etc/dropbear/dropbear_rsa_host_key ]]     && dropbearkey -t rsa     -f /etc/dropbear/dropbear_rsa_host_key 2>/dev/null || true
  [[ ! -f /etc/dropbear/dropbear_ecdsa_host_key ]]   && dropbearkey -t ecdsa   -f /etc/dropbear/dropbear_ecdsa_host_key 2>/dev/null || true
  [[ ! -f /etc/dropbear/dropbear_ed25519_host_key ]] && dropbearkey -t ed25519 -f /etc/dropbear/dropbear_ed25519_host_key 2>/dev/null || true
  grep -q '/bin/false' /etc/shells 2>/dev/null || echo '/bin/false' >> /etc/shells
  grep -q '/usr/sbin/nologin' /etc/shells 2>/dev/null || echo '/usr/sbin/nologin' >> /etc/shells
  cat > /etc/systemd/system/dropbear.service << DBSVC
[Unit]
Description=Dropbear SSH Server (${BRAND})
After=network.target
[Service]
Type=simple
ExecStart=$_DB_BIN -F -p ${DROPBEAR_PORT1} -p ${DROPBEAR_PORT2}
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
DBSVC
  systemctl daemon-reload
  systemctl enable dropbear
  systemctl restart dropbear
  sleep 2
  systemctl is-active --quiet dropbear && ok "Dropbear พร้อม (port $DROPBEAR_PORT1, $DROPBEAR_PORT2)" || warn "Dropbear ยังไม่พร้อม — ตรวจสอบ: journalctl -u dropbear"
fi

# ── BADVPN ───────────────────────────────────────────────────
info "ติดตั้ง BadVPN..."
if [[ ! -x /usr/bin/badvpn-udpgw ]]; then
  wget -q --timeout=15 -O /usr/bin/badvpn-udpgw "https://raw.githubusercontent.com/NevermoreSSH/Blueblue/main/newudpgw" 2>/dev/null && chmod +x /usr/bin/badvpn-udpgw || rm -f /usr/bin/badvpn-udpgw
  if [[ ! -f /usr/bin/badvpn-udpgw ]]; then
    wget -q --timeout=15 -O /usr/bin/badvpn-udpgw "https://raw.githubusercontent.com/bagaswastu/badvpn/master/udpgw/badvpn-udpgw" 2>/dev/null && chmod +x /usr/bin/badvpn-udpgw || true
  fi
fi
cat > /etc/systemd/system/${BRAND_DIR}-badvpn.service << EOF
[Unit]
Description=${BRAND} BadVPN UDP Gateway
After=network.target
[Service]
Type=simple
ExecStart=/usr/bin/badvpn-udpgw --listen-addr 127.0.0.1:${BADVPN_PORT} --max-clients 500
Restart=always
RestartSec=5
StandardOutput=null
StandardError=null
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable ${BRAND_DIR}-badvpn
systemctl restart ${BRAND_DIR}-badvpn
ok "BadVPN พร้อม (port $BADVPN_PORT)"

# ── WS-STUNNEL ─────────────────────────────────────────────
info "ติดตั้ง WS-Stunnel..."
cat > /usr/local/bin/ws-stunnel << 'WSPYEOF'
#!/usr/bin/python3
import socket, threading, select, time
LISTENING_ADDR='0.0.0.0'; LISTENING_PORT=80; BUFLEN=4096*4; TIMEOUT=60
DEFAULT_HOST='127.0.0.1:143'
RESPONSE=b'HTTP/1.1 101 Switching Protocols\r\nContent-Length: 104857600000\r\n\r\n'
class Server(threading.Thread):
    def __init__(self, host, port):
        threading.Thread.__init__(self); self.running=False; self.host=host; self.port=port
        self.threads=[]; self.threadsLock=threading.Lock()
    def run(self):
        self.soc=socket.socket(socket.AF_INET)
        self.soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.soc.settimeout(2); self.soc.bind((self.host,int(self.port))); self.soc.listen(128)
        self.running=True
        try:
            while self.running:
                try: c,addr=self.soc.accept(); c.setblocking(1)
                except socket.timeout: continue
                conn=ConnectionHandler(c,self,addr); conn.start(); self.addConn(conn)
        finally:
            self.running=False; self.soc.close()
    def addConn(self,conn):
        self.threadsLock.acquire()
        try:
            if self.running: self.threads.append(conn)
        finally: self.threadsLock.release()
    def removeConn(self,conn):
        self.threadsLock.acquire()
        try: self.threads.remove(conn)
        except: pass
        finally: self.threadsLock.release()
class ConnectionHandler(threading.Thread):
    def __init__(self, socClient, server, addr):
        threading.Thread.__init__(self); self.client=socClient; self.client_buffer=b''
        self.server=server; self.addr=addr; self.daemon=True
    def run(self):
        try:
            self.client.settimeout(TIMEOUT)
            self.client_buffer=self.client.recv(BUFLEN)
            hostPort=DEFAULT_HOST
            try:
                for line in self.client_buffer.decode(errors='ignore').split('\r\n'):
                    if line.lower().startswith('x-real-host:') or line.lower().startswith('host:'):
                        hostPort=line.split(':',1)[1].strip(); break
            except: pass
            host=hostPort.split(':')[0]; port=int(hostPort.split(':')[1]) if ':' in hostPort else 143
            self.client.send(RESPONSE); self._tunnel(host,port)
        except: pass
        finally: self.server.removeConn(self)
    def _tunnel(self, host, port):
        soc=None
        try:
            soc=socket.socket(socket.AF_INET); soc.settimeout(TIMEOUT); soc.connect((host,port))
            while True:
                r,_,_=select.select([self.client,soc],[],[],TIMEOUT)
                if not r: break
                for s in r:
                    data=s.recv(BUFLEN)
                    if not data: return
                    (soc if s is self.client else self.client).sendall(data)
        except: pass
        finally:
            if soc:
                try: soc.close()
                except: pass
def main():
    print(f'[ws-stunnel] Listening on port {LISTENING_PORT} -> {DEFAULT_HOST}')
    srv=Server(LISTENING_ADDR, LISTENING_PORT); srv.start()
    while True: time.sleep(60)
if __name__=='__main__': main()
WSPYEOF
chmod +x /usr/local/bin/ws-stunnel
cat > /etc/systemd/system/${BRAND_DIR}-sshws.service << EOF
[Unit]
Description=${BRAND} WS-Stunnel port 80 -> Dropbear:143
After=network.target dropbear.service
[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/ws-stunnel
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable ${BRAND_DIR}-sshws
ok "WS-Stunnel พร้อม (port $WS_TUNNEL_PORT -> Dropbear:$DROPBEAR_PORT1)"

# ── 3x-ui INSTALL (locked version, third-party open source) ─
XUI_LOCKED_VERSION="v2.9.4"
info "ติดตั้ง 3x-ui ${XUI_LOCKED_VERSION} (locked)..."
if ! command -v x-ui &>/dev/null; then
  _xui_sh=$(mktemp /tmp/xui-XXXXX.sh)
  curl -Ls --max-time 30 "https://raw.githubusercontent.com/MHSanaei/3x-ui/master/install.sh" -o "$_xui_sh" 2>/dev/null || warn "ดาวน์โหลด 3x-ui install.sh ล้มเหลว"
  if [[ -s "$_xui_sh" ]]; then
    printf "y\n${XUI_PORT}\n\n\n\n" | timeout 300 bash "$_xui_sh" "${XUI_LOCKED_VERSION}" >> /var/log/${BRAND_DIR}-xui-install.log 2>&1 || true
  fi
  rm -f "$_xui_sh"
fi
systemctl stop x-ui 2>/dev/null || true

XUI_DB="/etc/x-ui/x-ui.db"
_RAND_PATH=$(cat /dev/urandom | tr -dc 'a-z0-9' | head -c 12)
XUI_BASE_PATH="/${_RAND_PATH}/"
echo "$XUI_BASE_PATH" > /etc/${BRAND_DIR}/xui-path.conf

if [[ -f "$XUI_DB" ]]; then
  _XUI_HASH=$(python3 -c "import bcrypt; print(bcrypt.hashpw(b'${XUI_PASS}',bcrypt.gensalt()).decode())" 2>/dev/null || echo "${XUI_PASS}")
  sqlite3 "$XUI_DB" "UPDATE users SET username='${XUI_USER}', password='${_XUI_HASH}';" 2>/dev/null || true
  for _key in webPort webUsername webPassword webBasePath enableIpLimit enableTrafficStatistics timeLocation trafficDiffReset tgBotEnable checkUpdate; do
    sqlite3 "$XUI_DB" "DELETE FROM settings WHERE key='${_key}';" 2>/dev/null || true
  done
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('webPort','${XUI_PORT}');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('webUsername','${XUI_USER}');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('webPassword','${_XUI_HASH}');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('webBasePath','${XUI_BASE_PATH}');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('enableIpLimit','true');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('enableTrafficStatistics','true');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('timeLocation','Asia/Bangkok');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('trafficDiffReset','false');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('tgBotEnable','false');" 2>/dev/null || true
  sqlite3 "$XUI_DB" "INSERT INTO settings(key,value) VALUES('checkUpdate','false');" 2>/dev/null || true
  ok "3x-ui credentials + webBasePath ตั้งค่าแล้ว"
fi

systemctl start x-ui
REAL_XUI_PORT="$XUI_PORT"
_db_port=$(sqlite3 "$XUI_DB" "SELECT value FROM settings WHERE key='webPort';" 2>/dev/null)
[[ -n "$_db_port" ]] && REAL_XUI_PORT="$_db_port"
for _i in $(seq 1 10); do
  curl -s --max-time 2 -o /dev/null -w "%{http_code}" "http://127.0.0.1:${REAL_XUI_PORT}/" 2>/dev/null | grep -q "^[123]" && break
  sleep 2
done
echo "$REAL_XUI_PORT" > /etc/${BRAND_DIR}/xui-port.conf
ok "3x-ui พร้อม (port $REAL_XUI_PORT)"

# ── สร้าง inbounds (branding เป็นกลาง — ไม่อ้างอิงเครือข่ายมือถือใด ๆ) ──
info "สร้าง VLESS inbounds..."
export USE_IPV6
python3 << PYEOF
import sqlite3, uuid, json, os
DB='/etc/x-ui/x-ui.db'
use_ipv6 = os.environ.get('USE_IPV6','0')=='1'
listen_addr = '::' if use_ipv6 else ''
try:
    con = sqlite3.connect(DB)
    existing = [r[0] for r in con.execute("SELECT port FROM inbounds").fetchall()]
    inbounds = [
        (8080, '${BRAND} - Fast 1', 'vless', 'inbound-8080', '/vless'),
        (8880, '${BRAND} - Fast 2', 'vless', 'inbound-8880', '/vless'),
    ]
    for port, remark, proto, tag, ws_path in inbounds:
        if port in existing:
            print(f'[OK] {remark} มีอยู่แล้ว'); continue
        uid = str(uuid.uuid4())
        settings = json.dumps({'clients':[{'id':uid,'flow':'','email':f'default@{tag}','limitIp':2,'totalGB':0,'expiryTime':0,'enable':True}],'decryption':'none'})
        stream = json.dumps({'network':'ws','security':'none','wsSettings':{'path':ws_path,'headers':{}}})
        sniffing = json.dumps({'enabled':True,'destOverride':['http','tls']})
        con.execute("INSERT INTO inbounds (user_id,up,down,total,remark,enable,expiry_time,listen,port,protocol,settings,stream_settings,tag,sniffing) VALUES (1,0,0,0,?,1,0,?,?,?,?,?,?,?)",
            (remark, listen_addr, port, proto, settings, stream, tag, sniffing))
        print(f'[OK] {proto.upper()} {remark} (port {port})')
    con.commit(); con.close()
except Exception as e:
    print(f'[WARN] {e}')
PYEOF

if [[ $USE_IPV6 -eq 1 ]]; then
  echo "$SERVER_IPV6" > /etc/${BRAND_DIR}/my_ipv6.conf
  echo "1" > /etc/${BRAND_DIR}/use_ipv6.conf
else
  echo "0" > /etc/${BRAND_DIR}/use_ipv6.conf
fi
systemctl restart x-ui 2>/dev/null || true
sleep 2
ok "Inbounds พร้อม"

# ── ล็อก x-ui ห้ามอัพเดทอัตโนมัติ ──────────────────────────
mkdir -p /etc/systemd/system/x-ui.service.d
cat > /etc/systemd/system/x-ui.service.d/no-autoupdate.conf << 'DROPIN'
[Service]
ExecStartPre=-/bin/rm -f /usr/local/x-ui/.update_flag /usr/local/x-ui/update_flag /tmp/x-ui-update*
DROPIN
systemctl daemon-reload 2>/dev/null || true
ok "ปิด x-ui auto-update แล้ว"

# ── SSH API (Python) ──────────────────────────────────────────
info "ติดตั้ง SSH API..."
mkdir -p /opt/${BRAND_DIR}-ssh-api
cat > /opt/${BRAND_DIR}-ssh-api/app.py << PYEOF2
#!/usr/bin/env python3
"""${BRAND} SSH API"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import json, subprocess, os, datetime

def run_cmd(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
    return r.returncode == 0, r.stdout.strip(), r.stderr.strip()

def get_host():
    for f in ('/etc/${BRAND_DIR}/domain.conf', '/etc/${BRAND_DIR}/my_ip.conf'):
        if os.path.exists(f):
            v = open(f).read().strip()
            if v: return v
    return ''

def get_connections():
    counts = {}; total = 0
    for port in ['80','443','143','109','22']:
        try:
            r = subprocess.run(f"ss -tn state established 2>/dev/null | awk '{{print \\$4}}' | grep -c ':{port}\$' || echo 0", shell=True, capture_output=True, text=True)
            c = int(r.stdout.strip().split()[0]) if r.stdout.strip() else 0
        except: c = 0
        counts[port] = c; total += c
    counts['total'] = total
    return counts

def list_ssh_users():
    users = []
    try:
        with open('/etc/passwd') as f:
            for line in f:
                p = line.strip().split(':')
                if len(p) < 7: continue
                uid = int(p[2])
                if uid < 1000 or uid > 60000: continue
                if p[6] not in ['/bin/false','/usr/sbin/nologin','/bin/bash','/bin/sh']: continue
                uname = p[0]; u = {'user': uname, 'active': True, 'exp': None}
                exp_f = f'/etc/${BRAND_DIR}/exp/{uname}'
                if os.path.exists(exp_f): u['exp'] = open(exp_f).read().strip()
                if u['exp']:
                    try:
                        exp_date = datetime.date.fromisoformat(u['exp'])
                        u['active'] = exp_date >= datetime.date.today()
                    except: pass
                users.append(u)
    except: pass
    return users

def respond(h, code, data):
    body = json.dumps(data).encode()
    h.send_response(code)
    h.send_header('Content-Type', 'application/json')
    h.send_header('Content-Length', len(body))
    h.send_header('Access-Control-Allow-Origin', '*')
    h.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    h.send_header('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    h.end_headers()
    h.wfile.write(body)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        self.end_headers()
    def read_body(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            return json.loads(self.rfile.read(length)) if length > 0 else {}
        except: return {}
    def do_GET(self):
        if self.path == '/api/status':
            _, svc_drop, _ = run_cmd("systemctl is-active dropbear")
            _, svc_nginx, _ = run_cmd("systemctl is-active nginx")
            _, svc_xui, _ = run_cmd("systemctl is-active x-ui")
            _, udp, _ = run_cmd("pgrep -x badvpn-udpgw")
            _, ws, _ = run_cmd("systemctl is-active ${BRAND_DIR}-sshws")
            conns = get_connections(); users = list_ssh_users()
            respond(self, 200, {
                'ok': True, 'connections': conns.get('total', 0), 'total_users': len(users),
                'services': {
                    'ssh': True, 'dropbear': svc_drop.strip()=='active', 'nginx': svc_nginx.strip()=='active',
                    'badvpn': bool(udp.strip()), 'sshws': ws.strip()=='active', 'xui': svc_xui.strip()=='active',
                }
            })
        elif self.path == '/api/users':
            respond(self, 200, {'users': list_ssh_users()})
        elif self.path == '/api/info':
            xui_port = open('/etc/${BRAND_DIR}/xui-port.conf').read().strip() if os.path.exists('/etc/${BRAND_DIR}/xui-port.conf') else '${XUI_NGINX_PORT}'
            respond(self, 200, {'host': get_host(), 'xui_port': int(xui_port), 'dropbear_port': ${DROPBEAR_PORT1}, 'dropbear_port2': ${DROPBEAR_PORT2}, 'udpgw_port': ${BADVPN_PORT}})
        else:
            respond(self, 404, {'error': 'not found'})
    def do_POST(self):
        data = self.read_body()
        if self.path == '/api/login':
            u = data.get('username','').strip(); p = data.get('password','').strip()
            su = open('/etc/${BRAND_DIR}/xui-user.conf').read().strip() if os.path.exists('/etc/${BRAND_DIR}/xui-user.conf') else ''
            sp = open('/etc/${BRAND_DIR}/xui-pass.conf').read().strip() if os.path.exists('/etc/${BRAND_DIR}/xui-pass.conf') else ''
            if u == su and p == sp: return respond(self, 200, {'ok': True})
            return respond(self, 401, {'ok': False, 'error': 'invalid credentials'})
        elif self.path == '/api/speedtest':
            try:
                r = subprocess.run(['speedtest-cli','--json','--secure'], capture_output=True, text=True, timeout=60)
                if r.returncode == 0:
                    d = json.loads(r.stdout)
                    respond(self, 200, {'ok': True, 'ping': round(d.get('ping',0),1),
                        'download': round(d.get('download',0)/1000000,2), 'upload': round(d.get('upload',0)/1000000,2),
                        'server': d.get('server',{}).get('name','')})
                else:
                    respond(self, 200, {'ok': False, 'error': 'speedtest unavailable'})
            except Exception as e:
                respond(self, 200, {'ok': False, 'error': str(e)})
        elif self.path == '/api/create_ssh':
            user = data.get('user','').strip(); days = int(data.get('days', 30)); passwd = data.get('password','').strip()
            if not user or not passwd: return respond(self, 400, {'error':'user and password required'})
            ok1, _, _ = run_cmd(f"id {user} 2>/dev/null")
            if not ok1: run_cmd(f"useradd -M -s /bin/false {user}")
            run_cmd(f'echo "{user}:{passwd}" | chpasswd')
            exp_date = (datetime.date.today() + datetime.timedelta(days=days)).isoformat()
            run_cmd(f"chage -E {exp_date} {user}")
            with open(f'/etc/${BRAND_DIR}/exp/{user}', 'w') as f: f.write(exp_date)
            respond(self, 200, {'ok': True, 'user': user, 'exp': exp_date})
        elif self.path == '/api/delete_ssh':
            user = data.get('user','').strip()
            if not user: return respond(self, 400, {'error':'user required'})
            run_cmd(f"userdel -f {user} 2>/dev/null || true")
            try: os.remove(f'/etc/${BRAND_DIR}/exp/{user}')
            except: pass
            respond(self, 200, {'ok': True, 'user': user})
        elif self.path == '/api/extend_ssh':
            user = data.get('user','').strip(); days = int(data.get('days', 30))
            if not user: return respond(self, 400, {'error':'user required'})
            exp_f = f'/etc/${BRAND_DIR}/exp/{user}'
            if os.path.exists(exp_f):
                try:
                    old = datetime.date.fromisoformat(open(exp_f).read().strip())
                    new_exp = max(old, datetime.date.today()) + datetime.timedelta(days=days)
                except: new_exp = datetime.date.today() + datetime.timedelta(days=days)
            else:
                new_exp = datetime.date.today() + datetime.timedelta(days=days)
            run_cmd(f"chage -E {new_exp.isoformat()} {user}")
            with open(exp_f, 'w') as f: f.write(new_exp.isoformat())
            respond(self, 200, {'ok': True, 'user': user, 'exp': new_exp.isoformat()})
        else:
            respond(self, 404, {'error': 'not found'})

if __name__ == '__main__':
    server = HTTPServer(('127.0.0.1', ${SSH_API_PORT}), Handler)
    print('[${BRAND_DIR}-ssh-api] Listening on 127.0.0.1:${SSH_API_PORT}')
    server.serve_forever()
PYEOF2
chmod +x /opt/${BRAND_DIR}-ssh-api/app.py
cat > /etc/systemd/system/${BRAND_DIR}-ssh-api.service << EOF
[Unit]
Description=${BRAND} SSH API
After=network.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/${BRAND_DIR}-ssh-api/app.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable ${BRAND_DIR}-ssh-api
fuser -k ${SSH_API_PORT}/tcp 2>/dev/null || true
systemctl restart ${BRAND_DIR}-ssh-api
sleep 2
ok "SSH API พร้อม (port $SSH_API_PORT)"

# ── SSL CERTIFICATE ───────────────────────────────────────────
info "ขอ SSL Certificate สำหรับ ${DOMAIN}..."
SSL_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
SSL_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
USE_SSL=0
systemctl stop ${BRAND_DIR}-sshws 2>/dev/null || true
systemctl stop nginx 2>/dev/null || true
pkill -f ws-stunnel 2>/dev/null || true
pkill -9 -x nginx 2>/dev/null || true
for _w in 1 2 3 4 5; do lsof -ti tcp:80 &>/dev/null || break; sleep 1; done
if command -v certbot &>/dev/null; then
  for _try in 1 2 3; do
    timeout 90 certbot certonly --standalone --non-interactive --agree-tos --register-unsafely-without-email -d "$DOMAIN" 2>&1 | tail -5 || true
    [[ -f "$SSL_CERT" ]] && { USE_SSL=1; break; }
    sleep 5
  done
fi
[[ $USE_SSL -eq 1 ]] && ok "SSL Certificate พร้อม" || warn "ไม่มี SSL — ใช้ HTTP แทน"

# ── NGINX ──────────────────────────────────────────────────
info "ติดตั้ง Nginx..."
if ! command -v nginx &>/dev/null; then
  DEBIAN_FRONTEND=noninteractive timeout 120 apt-get install -y nginx
fi
rm -f /etc/nginx/conf.d/default.conf /etc/nginx/sites-enabled/default /etc/nginx/sites-available/default
mkdir -p /etc/nginx/conf.d
ufw allow 443/tcp &>/dev/null || true
ufw allow ${XUI_NGINX_PORT}/tcp &>/dev/null || true

_SSL_SNIPPET=""
[[ $USE_SSL -eq 1 ]] && _SSL_SNIPPET="ssl_certificate ${SSL_CERT}; ssl_certificate_key ${SSL_KEY}; ssl_protocols TLSv1.2 TLSv1.3;"
_LISTEN_443="listen 443${USE_SSL:+ ssl};"
[[ $USE_SSL -eq 1 ]] && _LISTEN_443="listen 443 ssl http2;"
_LISTEN_XUI="listen ${XUI_NGINX_PORT}${USE_SSL:+ ssl};"
[[ $USE_SSL -eq 1 ]] && _LISTEN_XUI="listen ${XUI_NGINX_PORT} ssl http2;"

cat > /etc/nginx/conf.d/${BRAND_DIR}.conf << EOF
server {
    ${_LISTEN_443}
    server_name ${DOMAIN} _;
    ${_SSL_SNIPPET}
    root /opt/${BRAND_DIR}-panel;
    index index.html;
    location / { try_files \$uri \$uri/ =404; add_header Cache-Control "no-store"; }
    location /api/ {
        if (\$request_method = OPTIONS) { add_header Access-Control-Allow-Origin "*"; add_header Access-Control-Allow-Methods "GET,POST,OPTIONS"; add_header Access-Control-Allow-Headers "Content-Type"; return 204; }
        proxy_pass http://127.0.0.1:${SSH_API_PORT}/api/;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_read_timeout 60s;
        add_header Access-Control-Allow-Origin "*" always;
    }
    location /xui-api/ {
        proxy_pass http://127.0.0.1:${REAL_XUI_PORT}${XUI_BASE_PATH};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header Cookie \$http_cookie;
        proxy_cookie_path ${XUI_BASE_PATH} /xui-api/;
        add_header Access-Control-Allow-Origin "\$http_origin" always;
        add_header Access-Control-Allow-Credentials "true" always;
    }
}
server {
    ${_LISTEN_XUI}
    server_name ${DOMAIN} _;
    ${_SSL_SNIPPET}
    location / {
        proxy_pass http://127.0.0.1:${REAL_XUI_PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Cookie \$http_cookie;
        proxy_cookie_path / /;
    }
}
EOF

if nginx -t 2>/dev/null; then
  systemctl restart nginx && ok "Nginx พร้อม (Dashboard:443 / 3x-ui proxy:${XUI_NGINX_PORT})" || warn "Nginx มีปัญหา"
else
  warn "Nginx config มีปัญหา — ตรวจ: nginx -t"
fi
sleep 1
systemctl start ${BRAND_DIR}-sshws 2>/dev/null || true

# ── FIREWALL ─────────────────────────────────────────────────
info "ตั้งค่า Firewall..."
ufw --force reset 2>/dev/null || true
ufw default deny incoming 2>/dev/null || true
ufw default allow outgoing 2>/dev/null || true
for port in 22 80 109 143 443 ${XUI_NGINX_PORT} 8080 8880; do ufw allow "$port"/tcp &>/dev/null; done
ufw allow ${BADVPN_PORT}/udp &>/dev/null
for port in ${SSH_API_PORT} ${XUI_PORT}; do ufw deny "$port"/tcp &>/dev/null; done
ufw --force enable &>/dev/null
ok "Firewall พร้อม"

# ── CONFIG.JS ────────────────────────────────────────────────
_PANEL_URL="https://${DOMAIN}"
[[ $USE_SSL -eq 0 ]] && _PANEL_URL="http://${DOMAIN}"
cat > /opt/${BRAND_DIR}-panel/config.js << EOF
window.XXTL_CONFIG = {
  brand: "${BRAND}",
  host: "${DOMAIN}",
  xui_port: ${REAL_XUI_PORT},
  panel_url: "${_PANEL_URL}"
};
EOF

# ── LOGIN PAGE (index.html) — minimal white/pastel ────────────
info "สร้าง Login Page..."
cat > /opt/${BRAND_DIR}-panel/index.html << 'HTMLEOF'
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>XXTLONLINE — Sign in</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Sarabun:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root{
    --primary:#7c6cf6; --primary-dark:#5b4fd6; --accent:#8fe3d0;
    --bg:#f6f5fb; --card:#ffffff; --text:#2d2a45; --muted:#8b87a3; --border:#ece9f7;
  }
  *{margin:0;padding:0;box-sizing:border-box;}
  body{
    font-family:'Sarabun',sans-serif; background:linear-gradient(160deg,#f6f5fb 0%,#eef0fb 45%,#f3f0fa 100%);
    min-height:100vh; display:flex; align-items:center; justify-content:center; padding:20px;
  }
  .blob{position:fixed;border-radius:50%;filter:blur(60px);opacity:.35;z-index:0;}
  .blob1{width:340px;height:340px;background:var(--primary);top:-100px;left:-100px;}
  .blob2{width:280px;height:280px;background:var(--accent);bottom:-80px;right:-80px;}
  .scene{position:relative;z-index:1;width:100%;max-width:400px;}
  .logo-wrap{display:flex;flex-direction:column;align-items:center;gap:10px;margin-bottom:26px;}
  .logo-badge{
    width:64px;height:64px;border-radius:18px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));
    display:flex;align-items:center;justify-content:center;box-shadow:0 10px 24px rgba(124,108,246,.35);
  }
  .logo-badge svg{width:30px;height:30px;}
  .brand-name{font-family:'Poppins',sans-serif;font-weight:800;font-size:1.5rem;color:var(--text);letter-spacing:.5px;}
  .brand-name span{color:var(--primary);}
  .brand-sub{font-family:'Poppins',sans-serif;font-size:.65rem;letter-spacing:3px;color:var(--muted);text-transform:uppercase;}
  .card{
    background:var(--card);border:1px solid var(--border);border-radius:22px;padding:32px 26px;
    box-shadow:0 20px 50px rgba(90,80,180,.10);
  }
  .card-title{font-family:'Poppins',sans-serif;font-weight:600;font-size:1.05rem;color:var(--text);margin-bottom:20px;}
  .field-group{margin-bottom:16px;}
  .field-label{display:block;font-size:.78rem;color:var(--muted);margin-bottom:6px;font-weight:500;}
  .field-wrap{position:relative;}
  .field-input{
    width:100%;background:#faf9ff;border:1.5px solid var(--border);border-radius:12px;
    padding:12px 14px;font-family:'Sarabun',sans-serif;font-size:.92rem;color:var(--text);outline:none;
    transition:border-color .2s,background .2s;
  }
  .field-input:focus{border-color:var(--primary);background:#fff;}
  .field-input::placeholder{color:#c3c0d6;}
  .eye-btn{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.9rem;}
  .btn{width:100%;padding:13px;border:none;border-radius:12px;font-family:'Sarabun',sans-serif;font-size:.95rem;font-weight:600;cursor:pointer;margin-bottom:10px;transition:transform .12s,box-shadow .12s;}
  .btn:last-child{margin-bottom:0;}
  .btn-primary{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;box-shadow:0 8px 20px rgba(124,108,246,.35);}
  .btn-primary:hover{transform:translateY(-1px);box-shadow:0 10px 26px rgba(124,108,246,.45);}
  .btn-primary:disabled{opacity:.6;cursor:not-allowed;transform:none;}
  .footer-note{text-align:center;font-size:.72rem;color:var(--muted);margin-top:18px;letter-spacing:.5px;}
</style>
</head>
<body>
<div class="blob blob1"></div>
<div class="blob blob2"></div>
<div class="scene">
  <div class="logo-wrap">
    <div class="logo-badge">
      <svg viewBox="0 0 24 24" fill="none"><path d="M4 12c2-5 6-8 8-8s6 3 8 8c-2 5-6 8-8 8s-6-3-8-8Z" stroke="#fff" stroke-width="1.8"/><circle cx="12" cy="12" r="3" fill="#fff"/></svg>
    </div>
    <div class="brand-name">XXTL<span>ONLINE</span></div>
    <div class="brand-sub">Secure Access Panel</div>
  </div>
  <div class="card">
    <div class="card-title">เข้าสู่ระบบ</div>
    <div class="field-group">
      <label class="field-label">ชื่อผู้ใช้</label>
      <div class="field-wrap">
        <input class="field-input" id="usernameInput" type="text" placeholder="กรอกชื่อผู้ใช้งาน" autocomplete="username">
      </div>
    </div>
    <div class="field-group" style="margin-bottom:22px">
      <label class="field-label">รหัสผ่าน</label>
      <div class="field-wrap">
        <input class="field-input" type="password" id="passInput" placeholder="กรอกรหัสผ่าน" autocomplete="current-password">
        <button class="eye-btn" onclick="togglePass()" tabindex="-1">👁</button>
      </div>
    </div>
    <button class="btn btn-primary" id="loginBtn" onclick="doLogin()">เข้าสู่ระบบ</button>
  </div>
  <div class="footer-note">XXTLONLINE &copy; VPN Panel</div>
</div>
<script>
function togglePass(){
  const f = document.getElementById('passInput');
  f.type = f.type === 'password' ? 'text' : 'password';
}
async function doLogin(){
  const user = document.getElementById('usernameInput').value.trim();
  const pass = document.getElementById('passInput').value.trim();
  const btn = document.getElementById('loginBtn');
  if(!user || !pass){ alert('กรุณากรอก Username และ Password'); return; }
  btn.disabled = true; btn.textContent = 'กำลังเข้าสู่ระบบ...';
  try{
    const r = await fetch('/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username:user, password:pass})});
    const d = await r.json();
    if(d.ok){
      sessionStorage.setItem('xxtl_auth', JSON.stringify({user, pass, exp: Date.now()+8*3600*1000}));
      location.replace('dashboard.html');
    } else {
      alert('Username หรือ Password ไม่ถูกต้อง');
      btn.disabled = false; btn.textContent = 'เข้าสู่ระบบ';
    }
  } catch(e){
    alert('เชื่อมต่อ API ไม่ได้: ' + e.message);
    btn.disabled = false; btn.textContent = 'เข้าสู่ระบบ';
  }
}
document.addEventListener('keydown', e => { if(e.key==='Enter') doLogin(); });
</script>
</body>
</html>
HTMLEOF
ok "Login Page พร้อม"

# ── DASHBOARD (dashboard.html) — minimal white/pastel ─────────
info "สร้าง Dashboard..."
cat > /opt/${BRAND_DIR}-panel/dashboard.html << 'DASHEOF'
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>XXTLONLINE — Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Sarabun:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root{--primary:#7c6cf6;--primary-dark:#5b4fd6;--accent:#8fe3d0;--bg:#f6f5fb;--card:#fff;--text:#2d2a45;--muted:#8b87a3;--border:#ece9f7;--good:#3dcf8e;--bad:#f2607a;}
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Sarabun',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding-bottom:40px;}
  .wrap{max-width:480px;margin:0 auto;}
  .hdr{background:linear-gradient(135deg,var(--primary),var(--primary-dark));padding:22px 20px 26px;color:#fff;border-radius:0 0 24px 24px;}
  .hdr-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;}
  .hdr-brand{font-family:'Poppins',sans-serif;font-weight:800;font-size:1.2rem;}
  .logout{background:rgba(255,255,255,.18);border:none;border-radius:8px;padding:6px 12px;font-size:.72rem;color:#fff;cursor:pointer;}
  .hdr-sub{font-size:.78rem;opacity:.85;}
  .content{padding:16px;}
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:16px;margin-bottom:12px;box-shadow:0 4px 16px rgba(90,80,180,.06);}
  .card-title{font-family:'Poppins',sans-serif;font-size:.72rem;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase;margin-bottom:12px;}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
  .stat{background:#faf9ff;border-radius:12px;padding:12px;text-align:center;}
  .stat-val{font-family:'Poppins',sans-serif;font-weight:700;font-size:1.3rem;color:var(--text);}
  .stat-lbl{font-size:.68rem;color:var(--muted);margin-top:2px;}
  .svc-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);font-size:.85rem;}
  .svc-row:last-child{border-bottom:none;}
  .dot{width:8px;height:8px;border-radius:50%;background:var(--good);display:inline-block;margin-right:8px;}
  .dot.off{background:var(--bad);}
  .btn{width:100%;padding:12px;border:none;border-radius:12px;font-size:.9rem;font-weight:600;cursor:pointer;font-family:'Sarabun',sans-serif;}
  .btn-primary{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;}
  .btn-outline{background:#faf9ff;border:1px solid var(--border);color:var(--text);}
  .field-input{width:100%;background:#faf9ff;border:1.5px solid var(--border);border-radius:10px;padding:10px 12px;font-size:.85rem;margin-bottom:8px;font-family:'Sarabun',sans-serif;}
  .user-item{display:flex;justify-content:space-between;align-items:center;padding:10px;background:#faf9ff;border-radius:10px;margin-bottom:8px;font-size:.82rem;}
  .badge{font-size:.65rem;padding:2px 8px;border-radius:20px;font-weight:600;}
  .badge-ok{background:rgba(61,207,142,.12);color:var(--good);}
  .badge-exp{background:rgba(242,96,122,.12);color:var(--bad);}
  .del-btn{background:none;border:none;color:var(--bad);cursor:pointer;font-size:.8rem;}
</style>
</head>
<body>
<div class="wrap">
  <div class="hdr">
    <div class="hdr-top">
      <div class="hdr-brand">XXTLONLINE</div>
      <button class="logout" onclick="doLogout()">ออกจากระบบ</button>
    </div>
    <div class="hdr-sub" id="hostLabel">กำลังโหลด...</div>
  </div>
  <div class="content">
    <div class="card">
      <div class="card-title">สถานะระบบ</div>
      <div class="grid2">
        <div class="stat"><div class="stat-val" id="connCount">-</div><div class="stat-lbl">Active Connections</div></div>
        <div class="stat"><div class="stat-val" id="userCount">-</div><div class="stat-lbl">SSH Users</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">บริการ</div>
      <div id="svcList"></div>
    </div>
    <div class="card">
      <div class="card-title">สร้างบัญชี SSH</div>
      <input class="field-input" id="newUser" placeholder="Username">
      <input class="field-input" id="newPass" type="password" placeholder="Password">
      <input class="field-input" id="newDays" type="number" placeholder="จำนวนวัน (เช่น 30)" value="30">
      <button class="btn btn-primary" onclick="createUser()">+ สร้างบัญชี</button>
    </div>
    <div class="card">
      <div class="card-title">รายชื่อผู้ใช้ SSH</div>
      <div id="userList">กำลังโหลด...</div>
    </div>
    <button class="btn btn-outline" onclick="openXui()">เปิดแผงควบคุม 3x-ui</button>
  </div>
</div>
<script>
function doLogout(){ sessionStorage.removeItem('xxtl_auth'); location.replace('index.html'); }
(function checkAuth(){
  const raw = sessionStorage.getItem('xxtl_auth');
  if(!raw){ location.replace('index.html'); return; }
  try{ const d = JSON.parse(raw); if(Date.now() > d.exp){ location.replace('index.html'); } }
  catch(e){ location.replace('index.html'); }
})();
async function loadInfo(){
  try{
    const r = await fetch('/api/info'); const d = await r.json();
    document.getElementById('hostLabel').textContent = d.host || '';
  }catch(e){}
}
async function loadStatus(){
  try{
    const r = await fetch('/api/status'); const d = await r.json();
    document.getElementById('connCount').textContent = d.connections ?? 0;
    document.getElementById('userCount').textContent = d.total_users ?? 0;
    const svc = d.services || {};
    const names = {ssh:'SSH',dropbear:'Dropbear',nginx:'Nginx',badvpn:'BadVPN',sshws:'WS-Stunnel',xui:'3x-ui'};
    let html = '';
    for(const k in names){
      const on = !!svc[k];
      html += `<div class="svc-row"><span><span class="dot ${on?'':'off'}"></span>${names[k]}</span><span>${on?'ทำงาน':'หยุด'}</span></div>`;
    }
    document.getElementById('svcList').innerHTML = html;
  }catch(e){}
}
async function loadUsers(){
  try{
    const r = await fetch('/api/users'); const d = await r.json();
    const list = d.users || [];
    if(list.length === 0){ document.getElementById('userList').innerHTML = '<div style="color:var(--muted);font-size:.82rem">ยังไม่มีผู้ใช้</div>'; return; }
    let html = '';
    list.forEach(u => {
      html += `<div class="user-item"><span>${u.user}<br><span class="badge ${u.active?'badge-ok':'badge-exp'}">${u.exp || '-'}</span></span><button class="del-btn" onclick="delUser('${u.user}')">ลบ</button></div>`;
    });
    document.getElementById('userList').innerHTML = html;
  }catch(e){}
}
async function createUser(){
  const user = document.getElementById('newUser').value.trim();
  const pass = document.getElementById('newPass').value.trim();
  const days = parseInt(document.getElementById('newDays').value || '30');
  if(!user || !pass){ alert('กรุณากรอก Username และ Password'); return; }
  try{
    const r = await fetch('/api/create_ssh', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({user, password: pass, days})});
    const d = await r.json();
    if(d.ok){ document.getElementById('newUser').value=''; document.getElementById('newPass').value=''; loadUsers(); loadStatus(); }
    else alert('สร้างไม่สำเร็จ: ' + (d.error || ''));
  }catch(e){ alert('ผิดพลาด: ' + e.message); }
}
async function delUser(user){
  if(!confirm(`ลบผู้ใช้ ${user}?`)) return;
  try{ await fetch('/api/delete_ssh', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({user})}); loadUsers(); loadStatus(); }
  catch(e){ alert('ผิดพลาด: ' + e.message); }
}
function openXui(){ window.open('/xui-api/', '_blank'); }
loadInfo(); loadStatus(); loadUsers();
setInterval(loadStatus, 15000);
</script>
</body>
</html>
DASHEOF
ok "Dashboard พร้อม"

# ── NETWORK TUNING (merged from vps-network-tune) ─────────────
info "จูนเครือข่าย VPS (BBR + FQ + RPS/RFS + IRQ balance)..."
IFACE=$(ip route show default | awk '/default/ {print $5; exit}')
if [[ -n "$IFACE" ]]; then
  NCPU=$(nproc)
  RPS_MASK=$(python3 -c "print(format((1 << $NCPU) - 1, 'x'))")
  SYSCTL_FILE="/etc/sysctl.d/99-${BRAND_DIR}-network-tune.conf"
  cat > "$SYSCTL_FILE" << 'SYSEOF'
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_mtu_probing = 1
net.core.netdev_max_backlog = 4096
net.ipv4.tcp_slow_start_after_idle = 0
net.core.rps_sock_flow_entries = 32768
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_ecn = 1
net.core.somaxconn = 8192
net.ipv4.tcp_max_syn_backlog = 8192
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 4194304
net.core.wmem_default = 4194304
net.ipv4.tcp_rmem = 4096 4194304 67108864
net.ipv4.tcp_wmem = 4096 4194304 67108864
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_moderate_rcvbuf = 1
net.ipv4.tcp_notsent_lowat = 131072
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_keepalive_time = 60
net.ipv4.tcp_keepalive_intvl = 10
net.ipv4.tcp_keepalive_probes = 4
fs.file-max = 2097152
net.ipv4.ip_local_port_range = 1024 65535
net.core.netdev_budget = 600
net.core.netdev_budget_usecs = 8000
SYSEOF
  sysctl --system > /dev/null 2>&1
  tc qdisc replace dev "$IFACE" root fq 2>/dev/null || true

  cat > /usr/local/sbin/${BRAND_DIR}-rps-apply.sh << SCRIPTEOF
#!/bin/bash
IFACE="$IFACE"
RPS_MASK="$RPS_MASK"
for rx in /sys/class/net/\$IFACE/queues/rx-*; do
  [ -f "\$rx/rps_cpus" ] && echo "\$RPS_MASK" > "\$rx/rps_cpus"
  [ -f "\$rx/rps_flow_cnt" ] && echo "32768" > "\$rx/rps_flow_cnt"
done
tc qdisc replace dev "\$IFACE" root fq 2>/dev/null || true
ip link set dev "\$IFACE" txqueuelen 10000 2>/dev/null || true
SCRIPTEOF
  chmod +x /usr/local/sbin/${BRAND_DIR}-rps-apply.sh
  cat > /etc/systemd/system/${BRAND_DIR}-rps-tune.service << UNITEOF
[Unit]
Description=${BRAND} network tuning (RPS/RFS + qdisc)
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/${BRAND_DIR}-rps-apply.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  systemctl enable ${BRAND_DIR}-rps-tune.service > /dev/null 2>&1
  systemctl restart ${BRAND_DIR}-rps-tune.service

  LIMITS_FILE="/etc/security/limits.d/99-${BRAND_DIR}-network-tune.conf"
  cat > "$LIMITS_FILE" << 'LIMEOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
LIMEOF

  systemctl enable irqbalance > /dev/null 2>&1
  systemctl restart irqbalance 2>/dev/null || true
  ok "จูนเครือข่ายเสร็จสิ้น (interface: $IFACE, RPS mask: $RPS_MASK)"
else
  warn "ไม่พบ default network interface — ข้ามการจูนเครือข่าย"
fi

# ── SUMMARY ────────────────────────────────────────────────
echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  ${BRAND} ติดตั้งเสร็จสมบูรณ์${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "  Dashboard : ${CYAN}${_PANEL_URL}${NC}"
echo -e "  3x-ui     : ${CYAN}${_PANEL_URL/:*/}:${XUI_NGINX_PORT}${NC}"
echo -e "  SSH host  : ${CYAN}${DOMAIN}${NC}  (port ${DROPBEAR_PORT1} / ${DROPBEAR_PORT2}, ws-tunnel port 80)"
echo -e "  Username  : ${CYAN}${XUI_USER}${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
