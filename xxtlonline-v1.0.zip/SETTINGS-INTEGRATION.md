# XXTLONLINE Settings Page — Integration Guide

**Add comprehensive admin settings panel to your installation**

---

## 📋 What's Included

### **1. settings.html** — Full admin panel UI
- 6 comprehensive tabs
- Real-time system monitoring
- Configuration management
- Security settings
- Network tuning
- Backup management

### **2. SETTINGS-API.py** — Backend API endpoints
- 15+ new endpoints for settings management
- Service control (start/stop/restart)
- SSL certificate renewal
- Firewall rule management
- Network tuning adjustment
- Backup creation & listing
- Password & domain changes

### **3. Dashboard Integration**
- Links from dashboard to settings
- Unified navigation

---

## 🚀 Installation (2 Methods)

### **Method 1: Update Existing Installation**

#### **Step 1: Add settings.html to panel**
```bash
# SSH into server
ssh root@panel.example.com

# Copy settings page
cp settings.html /opt/xxtlonline-panel/

# Verify
ls -l /opt/xxtlonline-panel/
```

#### **Step 2: Update xxtlonline-ssh-api/app.py**
```bash
# Backup original
cp /opt/xxtlonline-ssh-api/app.py /opt/xxtlonline-ssh-api/app.py.backup

# Edit app.py and add new endpoints
# Copy content from SETTINGS-API.py into app.py
# Insert into existing do_GET and do_POST handlers
```

**Detailed merge instructions:**

1. Open `/opt/xxtlonline-ssh-api/app.py` in editor
   ```bash
   nano /opt/xxtlonline-ssh-api/app.py
   ```

2. At top of file (after other imports), add:
   ```python
   import hashlib, subprocess, time, datetime
   ```

3. In `do_GET` handler, after other `elif` statements, add the new GET endpoints from SETTINGS-API.py

4. In `do_POST` handler, after other `elif` statements, add the new POST endpoints from SETTINGS-API.py

5. Save and exit

#### **Step 3: Restart API service**
```bash
sudo systemctl restart xxtlonline-ssh-api

# Verify it's running
sudo systemctl status xxtlonline-ssh-api

# Check logs for errors
sudo journalctl -u xxtlonline-ssh-api -n 20
```

#### **Step 4: Update Dashboard Navigation**
Edit `/opt/xxtlonline-panel/dashboard.html` and add Settings link:

Find this line:
```html
<button class="btn btn-outline" onclick="openXui()">เปิดแผงควบคุม 3x-ui</button>
```

Replace with:
```html
<button class="btn btn-outline" onclick="location='settings.html'">⚙️ Settings</button>
<button class="btn btn-outline" onclick="openXui()">เปิดแผงควบคุม 3x-ui</button>
```

#### **Step 5: Verify Installation**
```bash
# Check API responds to new endpoints
curl http://localhost:6789/api/settings/server

# Should return JSON with server info
```

Test in browser:
```
https://panel.example.com/settings.html
```

---

### **Method 2: Fresh Installation with Settings (Automatic)**

If you're installing from scratch, you can generate a modified installer that includes settings:

```bash
# The xxtlonline-setup.sh can be modified to:
# 1. Create settings.html in panel directory
# 2. Add API endpoints automatically
# 3. Update dashboard with Settings link

# For now, use Method 1 above for existing installations
```

---

## 🎯 Features by Tab

### **Tab 1: Overview**
- ✅ System uptime
- ✅ Disk usage
- ✅ Active SSH users
- ✅ Active connections
- ✅ All services status
- ✅ Quick action buttons (SSL renew, Backup)

### **Tab 2: Server Settings**
- ✅ Server IP & domain display
- ✅ Change domain (with warning)
- ✅ View all ports
- ✅ Server information

### **Tab 3: Security**
- ✅ Change admin password
- ✅ View SSL certificate details
- ✅ Renew SSL certificate
- ✅ Firewall status
- ✅ Add/remove firewall rules

### **Tab 4: Network**
- ✅ View current network tuning
- ✅ BBR status
- ✅ Queue discipline info
- ✅ Buffer sizes
- ✅ Manual tuning (advanced)

### **Tab 5: Backup & Restore**
- ✅ Create backups on-demand
- ✅ View backup history
- ✅ Download backups
- ✅ Restore instructions

### **Tab 6: System**
- ✅ System information (uptime, kernel, disk)
- ✅ Service management (start/stop/restart)
- ✅ View service logs (last 50 lines)
- ✅ Log filtering by service

---

## 🔒 Security Considerations

### **API Endpoints** (Localhost Only)
- All new endpoints available at `http://localhost:6789/api/settings/*`
- **NOT exposed to WAN by default**
- Accessed through web panel via reverse proxy
- Authentication via session token

### **Protected Operations**
- ✅ Password change requires current password verification
- ✅ Domain change shows warning
- ✅ Service restart shows confirmation
- ✅ Network tuning limited to safe parameters

### **Safe Parameters** (Whitelist)
```
net.ipv4.tcp_rmem
net.ipv4.tcp_wmem
net.core.rmem_max
net.core.wmem_max
net.core.netdev_max_backlog
net.ipv4.tcp_fastopen
```

---

## 📊 API Endpoints Reference

### **GET Endpoints** (Read-only)

| Endpoint | Purpose |
|----------|---------|
| `/api/settings/server` | Server config (domain, IP, ports) |
| `/api/settings/system` | System info (uptime, kernel, disk) |
| `/api/settings/network` | Network tuning status |
| `/api/settings/ssl` | SSL certificate details |
| `/api/settings/firewall` | Firewall rules & status |
| `/api/settings/backup` | Backup list & sizes |

### **POST Endpoints** (Action-based)

| Endpoint | Purpose |
|----------|---------|
| `/api/settings/password-change` | Change admin password |
| `/api/settings/domain-change` | Update domain name |
| `/api/settings/ssl-renew` | Renew SSL certificate |
| `/api/settings/backup-now` | Create backup immediately |
| `/api/settings/service-action` | Start/stop/restart services |
| `/api/settings/network-tuning` | Adjust network parameters |
| `/api/settings/firewall-action` | Manage firewall rules |
| `/api/settings/logs` | Retrieve service logs |
| `/api/settings/theme` | Change UI theme |

---

## 🔧 Troubleshooting

### **Settings page won't load**
```bash
# Check if settings.html exists
ls -l /opt/xxtlonline-panel/settings.html

# Check if API is responding
curl http://localhost:6789/api/settings/server

# Check API logs
sudo journalctl -u xxtlonline-ssh-api -n 20
```

### **API returns errors**
```bash
# Restart API service
sudo systemctl restart xxtlonline-ssh-api

# Check for Python errors
sudo journalctl -u xxtlonline-ssh-api -n 50 | grep -i error

# Verify imports in app.py
python3 -c "import subprocess, time, datetime, hashlib; print('Imports OK')"
```

### **Settings not persisting**
```bash
# Check file permissions
ls -l /etc/xxtlonline/

# Verify API has write access
sudo touch /etc/xxtlonline/test.txt
sudo rm /etc/xxtlonline/test.txt
```

### **Firewall rules not applying**
```bash
# Check if UFW is enabled
sudo ufw status

# Verify rule was added
sudo ufw status numbered | grep 80

# Manually add if needed
sudo ufw allow 80/tcp
```

---

## 📝 Manual API Testing

### **Test Server Settings Endpoint**
```bash
curl -s http://localhost:6789/api/settings/server | jq
```

### **Test Creating Backup**
```bash
curl -X POST http://localhost:6789/api/settings/backup-now \
  -H "Content-Type: application/json" \
  -d '{}'
```

### **Test Password Change** (via UI is safer)
```bash
curl -X POST http://localhost:6789/api/settings/password-change \
  -H "Content-Type: application/json" \
  -d '{
    "user": "admin",
    "old_password": "oldpass",
    "new_password": "newpass"
  }'
```

### **Test Service Restart**
```bash
curl -X POST http://localhost:6789/api/settings/service-action \
  -H "Content-Type: application/json" \
  -d '{
    "service": "dropbear",
    "action": "restart"
  }'
```

---

## 🎯 Common Tasks

### **Update Admin Password**
1. Go to Settings → Security → Administrator Password
2. Enter current password
3. Enter new password twice
4. Click "Change Password"

### **Renew SSL Certificate**
1. Go to Settings → Security → SSL Certificate
2. Check current expiry date
3. Click "Renew Certificate"
4. Wait 1-2 minutes
5. Refresh to verify new date

### **Create Backup**
1. Go to Settings → Backup & Restore
2. Click "Create Backup Now"
3. Wait for confirmation
4. Download from backup list (via SSH)

### **View Service Logs**
1. Go to Settings → System
2. Select service from dropdown
3. Click "View Logs (Last 50 lines)"
4. Logs appear below

### **Change Domain**
1. Go to Settings → Server Settings
2. Update DNS A record first
3. Enter new domain
4. Click "Update Domain"
5. Wait for SSL to renew

### **Adjust Network Tuning** (Advanced)
1. Go to Settings → Network → Manual Tuning
2. Select parameter from dropdown
3. Enter new value
4. Click "Apply Tuning"
5. ⚠️ Only if you know what you're doing!

---

## 📋 Checklist After Installation

- [ ] `settings.html` copied to `/opt/xxtlonline-panel/`
- [ ] API endpoints added to `app.py`
- [ ] API service restarted
- [ ] Dashboard link updated
- [ ] Tested Settings page loads (`https://panel.example.com/settings.html`)
- [ ] Tested server info endpoint
- [ ] Tested creating backup
- [ ] Tested viewing logs
- [ ] Tested firewall status

---

## 🔄 Updates & Maintenance

### **Update settings.html**
```bash
# Replace file with new version
cp settings.html /opt/xxtlonline-panel/settings.html

# Reload in browser (Ctrl+F5)
```

### **Update API endpoints**
```bash
# Edit app.py
nano /opt/xxtlonline-ssh-api/app.py

# Restart service
sudo systemctl restart xxtlonline-ssh-api
```

### **Backup settings configuration**
```bash
# Settings are stored in:
# /etc/xxtlonline/
# /etc/x-ui/x-ui.db
# /etc/letsencrypt/

# Standard backup covers these
sudo xxtlonline-utils.sh backup
```

---

## 💡 Tips & Best Practices

1. **Don't change domain often** — Requires DNS + SSL renewal
2. **Test firewall rules carefully** — Wrong rules can block access
3. **Network tuning** — Default settings are optimized, only change if needed
4. **Backup before major changes** — Always have fallback
5. **Monitor logs regularly** — Catch issues early
6. **Update passwords quarterly** — Security best practice
7. **Keep SSL renewed** — Auto-renewal handles this, but monitor anyway

---

## 🆘 Getting Help

If settings don't work:

1. **Check logs**
   ```bash
   sudo journalctl -u xxtlonline-ssh-api -n 50
   ```

2. **Verify installation**
   ```bash
   ls -l /opt/xxtlonline-panel/settings.html
   curl http://localhost:6789/api/settings/server
   ```

3. **Restart services**
   ```bash
   sudo systemctl restart xxtlonline-ssh-api
   sudo systemctl restart nginx
   ```

4. **Check permissions**
   ```bash
   ls -l /etc/xxtlonline/
   ls -l /opt/xxtlonline-ssh-api/
   ```

---

## 📚 Related Files

- `settings.html` — Settings page UI
- `SETTINGS-API.py` — API endpoints code
- `dashboard.html` — Main dashboard (needs Settings link)
- `xxtlonline-ssh-api/app.py` — Main API server
- `/etc/xxtlonline/` — Configuration directory

---

**Status**: ✅ Ready to integrate  
**Version**: 1.0  
**Last Updated**: 2026-07-21
